package model;

public class Macros {
    public static final int BAD_SELECTION = -2;
    public static final int QUIT_GAME = -1;
}
